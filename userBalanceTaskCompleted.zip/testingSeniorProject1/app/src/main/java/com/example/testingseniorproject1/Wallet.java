package com.example.testingseniorproject1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Wallet extends AppCompatActivity implements View.OnClickListener{

    TextView textView;
    ImageView backButton;
    private DatabaseReference reference;
    private FirebaseUser user;
    private String userID;
    private double credit;
    TextView userBalance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);

        textView = (TextView) findViewById(R.id.textView3);
        backButton = (ImageView) findViewById(R.id.backButton3);
        backButton.setOnClickListener(this);

        userBalance = findViewById(R.id.userBalanceTextView);


        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userID = user.getUid();

        reference.child(userID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if(task.isSuccessful()){

                    if(task.getResult().exists()){
                        DataSnapshot dataSnapshot = task.getResult();
                        String balance = String.valueOf(dataSnapshot.child("credit").getValue());
                        userBalance.setText(balance);

                    }else{
                        Toast.makeText(Wallet.this, "Failed to get balance", Toast.LENGTH_SHORT).show();

                    }

                } else {

                    Toast.makeText(Wallet.this, "Failed to get balance", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onClick(View view) {




        if (view.getId() == R.id.backButton3){
            startActivity(new Intent(this, HomePage.class));
        }
    }
}
