package com.example.testingseniorproject1;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class HomePage extends AppCompatActivity implements View.OnClickListener{

    ImageView menu;
    Button button1, button2, button3, button4, button5, button6, button7, button8, scannerQRCode;
    private boolean IsVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        menu = (ImageView) findViewById(R.id.menu);
        menu.setOnClickListener(this);
        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(this);
        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(this);
        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(this);
        button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(this);
        button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(this);
        button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(this);
        button7 = (Button) findViewById(R.id.button7);
        button7.setOnClickListener(this);
        button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(this);
        scannerQRCode = (Button) findViewById(R.id.scannerQRCode);
        scannerQRCode.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        //------------------------------------------------------------------------------------------
        //Show Menu
        if (view.getId() == R.id.menu){
            if (IsVisible == false) {
                button1.setVisibility(View.VISIBLE);
                button2.setVisibility(View.VISIBLE);
                button3.setVisibility(View.VISIBLE);
                button4.setVisibility(View.VISIBLE);
                button5.setVisibility(View.VISIBLE);
                button6.setVisibility(View.VISIBLE);
                button7.setVisibility(View.VISIBLE);
                button8.setVisibility(View.VISIBLE);
                IsVisible = true;
            }else if (IsVisible == true){
                button1.setVisibility(View.INVISIBLE);
                button2.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                button6.setVisibility(View.INVISIBLE);
                button7.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                IsVisible = false;
            }
        }
        //------------------------------------------------------------------------------------------
        //
        switch (view.getId()){
            case R.id.button1://My Account
                startActivity(new Intent(this, MyAccount.class));
                break;

            case R.id.button2://Ride History
                startActivity(new Intent(this, RideHistory.class));
                break;

            case R.id.button3://Wallet
                startActivity(new Intent(this, Wallet.class));
                break;

            case R.id.button4://Add Coupon
                startActivity(new Intent(this, AddCoupon.class));
                break;

            case R.id.button5://Notification
                startActivity(new Intent(this, Notification.class));
                break;

            case R.id.button6://Help
                startActivity(new Intent(this, Help.class));
                break;

            case R.id.button7://AboutUs
                startActivity(new Intent(this, AboutUs.class));
                break;

            case R.id.button8://Logout
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(this, MainActivity.class));
                break;

            case R.id.scannerQRCode:
                scanQRCode();
                break;
        }


    }

    private void scanQRCode(){
        scannerQRCode = findViewById(R.id.scannerQRCode);
        findViewById(R.id.scannerQRCode).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                IntentIntegrator intentIntegrator = new IntentIntegrator(HomePage.this);
                intentIntegrator.setPrompt("Scan QR Code");
                intentIntegrator.initiateScan();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if(intentResult != null){

            if(intentResult.getContents()==null){
                Toast.makeText(this,"Canceled", Toast.LENGTH_SHORT).show();
            } else{
                // here if the scan was successful a pop up message for the trip details should appear
            }

        } else {
            super.onActivityResult(requestCode, resultCode, data);

        }

    }
}
