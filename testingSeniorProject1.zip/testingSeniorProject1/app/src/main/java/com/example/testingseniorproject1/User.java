package com.example.testingseniorproject1;

public class User {
    public String username, email;
    public double credit = 100.0; //when a new user registers he/she gets 100.0 in their balance for just signing up

    public User(){}

    public User(String username, String email){
        this.username = username;
        this.email = email;
    }

}
